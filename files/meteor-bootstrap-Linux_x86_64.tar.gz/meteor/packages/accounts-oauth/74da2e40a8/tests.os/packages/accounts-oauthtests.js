(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                     //
// packages/accounts-oauth/oauth_tests.js                                                              //
//                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                       //
// XXX Add a test to ensure that successful logins call Accounts.updateOrCreateUserFromExternalService // 1
// XXX Add a test to ensure that a missing or failed loginResult is handled correctly                  // 2
                                                                                                       // 3
/////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
